# bfr-code-test
A simple code test to send to web developer applicants

## Bonfire Red Code Test Instructions

We have provided a Photoshop file and a folder with images and fonts that you will need to create a simple one page website. Only the first image in the slider is visible in the Photoshop file, please make sure to include slider-image-2 and slider-image-3 in that section.

Please try to match the design of the Photoshop file and any functionality that you see fit. This means it's completely open to your interpretation, so use any library/framework/whatever you deem necessary. Put your own spin on some of the elements, we’re not a typical digital shop and don’t want to see cookie-cutter thinking. Show us what makes you the best candidate by adding in your own flavor to what we’re asking here.

Send us your cool shit! Don't push to this repo, instead send us your own link. Dropbox, .zip files, host on your own site are all examples of great ways to get it to us.

Reply to the Bonfire Code Test Recruiter Box email with your badass, fully responsive, final link.

Your mission, if you choose to accept it, is to take this design, and use your mad fuckin skillz to bring it to life.
